package net.dynu.brnstream.minilauncher;

import android.content.Context;
import android.content.Intent;

import java.util.ArrayList;

public class Global {
    public static ArrayList<String> Name = new ArrayList<String>();
    public static ArrayList<String> PackName = new ArrayList<String>();
}