# MiniLauncher
 This is my minimal launcher.
